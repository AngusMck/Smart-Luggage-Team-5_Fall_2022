package com.example.smartluggage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

public class ip_input extends AppCompatActivity {

    private EditText ip_text;
    private String ip_string;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_ip_input);

        ip_text = (EditText) findViewById(R.id.ip_address);
    }

    public void backtoNavigation(View view) {
        Intent intent = new Intent(this, Navigation.class);
        startActivity(intent);
        finish();
    }

    public void movetoMap(View view) {
        ip_string = ip_text.getText().toString();
        Intent intent = new Intent(this,Map.class);
        intent.putExtra("ip_string", ip_string);
        startActivity(intent);
        finish();
    }
}