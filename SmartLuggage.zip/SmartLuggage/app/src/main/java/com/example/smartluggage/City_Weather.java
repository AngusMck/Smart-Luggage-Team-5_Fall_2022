package com.example.smartluggage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class City_Weather extends AppCompatActivity {

    private EditText cityName, stateName;
    private String name, name2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_city_weather);

        cityName = (EditText) findViewById(R.id.city_name);
        stateName = (EditText) findViewById(R.id.state_name);
    }

    public void movetoWeather(View view) {
        name = cityName.getText().toString();
        name2 = stateName.getText().toString();
        if (name.equals("")) {
            Toast.makeText(this, "Enter City name.....", Toast.LENGTH_SHORT).show();
        }
        else {
            Intent intent = new Intent(this, Weather_Report.class);
            intent.putExtra("name",name );
            intent.putExtra("name2",name2 );
            startActivity(intent);
            finish();
        }
    }

    public void backtoNavigation(View view) {
        Intent intent = new Intent(this,Navigation.class);
        startActivity(intent);
        finish();
    }
}