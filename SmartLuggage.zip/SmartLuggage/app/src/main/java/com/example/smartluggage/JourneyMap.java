package com.example.smartluggage;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.smartluggage.databinding.ActivityJourneyMapBinding;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class JourneyMap extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityJourneyMapBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

     binding = ActivityJourneyMapBinding.inflate(getLayoutInflater());
     setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.clear();
        LatLng first_location = new LatLng(Journey.first_lat, Journey.first_long);
        LatLng last_location = new LatLng(Journey.last_lat, Journey.last_long);
        float zoom_lvl = 18.0f; // up to 21 if needed
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(first_location, zoom_lvl));
        mMap.addMarker(new MarkerOptions().position(first_location).title("Start"));
        mMap.addMarker(new MarkerOptions().position(last_location).title("Finish"));

        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.addAll(Journey.coordList);
        // Adding multiple points in map using polyline and arraylist
        mMap.addPolyline(polylineOptions);


        // set up button to locate user
        Button btn2 = (Button)findViewById(R.id.locate);
        // listen for when button is pressed in order to get its input
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // move the camera back onto the users location to easily find themselves
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(first_location, zoom_lvl));
            }
        });

        Button btn = (Button)findViewById(R.id.exit);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(JourneyMap.this, Journey.class));
            }
        });
    }
}