package com.example.smartluggage;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.smartluggage.databinding.ActivityMapBinding;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;

public class Map extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker on current location and move the camera
        // get lat and long from MainActivity
        LatLng phone_location = new LatLng(Home.latitude, Home.longitude);
        // add marker used to display the location of the phone
        mMap.addMarker(new MarkerOptions().position(phone_location).title("Phone Location"));
        // can control the camera with a specific zoom and centers the screen on lat long
        float zoom_lvl = 18.0f; // up to 21 if needed
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(phone_location, zoom_lvl));


        // in order to keep the lat and long updated set up a handler (for loop)
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // retrieve the lat and long again (main activity updates it in the background)
                LatLng phone_location = new LatLng(Home.latitude, Home.longitude);
                mMap.clear(); // clear map before adding new marker to avoid duplicates
                mMap.addMarker(new MarkerOptions().position(phone_location).title("Phone Location"));
                handler.postDelayed(this, 1000);
                // don't reset zoom so the user can scroll freely!
            }
        }, 1000); // runs every 2 seconds



        // set up button to locate user
        Button btn2 = (Button)findViewById(R.id.locate);
        // listen for when button is pressed in order to get its input
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // move the camera back onto the users location to easily find themselves
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(phone_location, zoom_lvl));
            }
        });

        Button btn = (Button)findViewById(R.id.exit);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Map.this, Navigation.class));
            }
        });
    }


}



