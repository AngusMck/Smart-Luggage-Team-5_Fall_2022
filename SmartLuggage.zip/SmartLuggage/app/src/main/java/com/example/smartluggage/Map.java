package com.example.smartluggage;

import androidx.fragment.app.FragmentActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.smartluggage.databinding.ActivityMapBinding;


import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Map extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapBinding binding;
    public double luggage_lat;
    public double luggage_long;
    private String ip_string;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ip_string = getIntent().getStringExtra("ip_string");

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker on current location and move the camera
        // get lat and long from MainActivity
        LatLng phone_location = new LatLng(Home.latitude, Home.longitude);
        // add marker used to display the location of the phone
        mMap.addMarker(new MarkerOptions().position(phone_location).title("Phone Location"));
        // can control the camera with a specific zoom and centers the screen on lat long
        float zoom_lvl = 18.0f; // up to 21 if needed
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(phone_location, zoom_lvl));



        // in order to keep the lat and long updated set up a handler (for loop)
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // retrieve the lat and long again (main activity updates it in the background)
                LatLng phone_location = new LatLng(Home.latitude, Home.longitude);
                mMap.clear(); // clear map before adding new marker to avoid duplicates
                mMap.addMarker(new MarkerOptions().position(phone_location).title("Phone Location"));

                if (ip_string.equals("none")) {

                }
                else {
                    new JsonTask().execute("http://" + ip_string + "/"); // for at apartment static ip

                    LatLng luggage_location = new LatLng(luggage_lat, luggage_long);

                    mMap.addMarker(new MarkerOptions().position(luggage_location).title("Luggage Location"));
                }

                handler.postDelayed(this, 1000);
            }
        }, 1000);

        // set up button to locate user
        Button btn2 = (Button)findViewById(R.id.locate);
        // listen for when button is pressed in order to get its input
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // move the camera back onto the users location to easily find themselves
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(phone_location, zoom_lvl));
            }
        });

        Button btn = (Button)findViewById(R.id.exit);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Map.this, Navigation.class));
            }
        });
    }




    // code for handling reading the data from the website into variables
    private class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    Log.d("Response: ", "> " + line);   //here ull get whole response

                }

                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            String separated_lat = StringUtils.substringBetween(result, "<a>", "</a>");
            String separated_long = StringUtils.substringBetween(result, "<b>", "</b>");
            luggage_lat = Double.valueOf(separated_lat);
            luggage_long = Double.valueOf(separated_long);
        }
    }
}
