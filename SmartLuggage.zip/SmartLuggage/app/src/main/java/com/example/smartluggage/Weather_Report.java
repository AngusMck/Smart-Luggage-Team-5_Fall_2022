package com.example.smartluggage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.weatherapp.db.WeatherDatabase;
import com.example.weatherapp.db.entities.cityName;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Weather_Report extends AppCompatActivity {

    //private WeatherDatabase db;
    private String  name, name2, url, stateName, countryName;
    private double uv_double, temp_double, rh_double, feels_double, precip_double;
    private TextView cityTextView , stateTextView , temperatureTextView , descriptionTextView;
    private TextView precipTextView, uvTextView, feelsTextView , humidityTextView;
    private JSONObject find;
    ProgressDialog progressDialog ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_weather_report);


    cityTextView = (TextView) findViewById(R.id.city_name_textView);
    stateTextView = (TextView) findViewById(R.id.state_name_textView);
    temperatureTextView = (TextView) findViewById(R.id.temperature_textView);
    descriptionTextView = (TextView) findViewById(R.id.description_textView);
    precipTextView = (TextView) findViewById(R.id.precip_textView);
    uvTextView = (TextView) findViewById(R.id.uv_textView);
    feelsTextView = (TextView) findViewById(R.id.feels_textView);
    humidityTextView = (TextView) findViewById(R.id.humidity_textView);

    //db = Room.databaseBuilder(this, WeatherDatabase.class, "student-db").allowMainThreadQueries().build();


    name= getIntent().getStringExtra("name");
    name2= getIntent().getStringExtra("name2");
    // https://api.weatherbit.io/v2.0/current?&city=Houston&key=39071c4025a2475e991bb51310f19dbc&units=I
    url = "https://api.weatherbit.io/v2.0/current?&city=" + name + "," + name2 + "&key=39071c4025a2475e991bb51310f19dbc&units=I";

    Search();

    }


    private void Search() {


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, response -> {
            try {

/*
                cityName city = db.CityDAO().getCity(name.toLowerCase());
                if(city ==null)
                {

                    cityName c = new cityName();
                    c.cityName = name;
                    db.CityDAO().insert(c);


                }

                cityName city1 = db.CityDAO().getCity(name);
*/
                JSONArray details = response.getJSONArray("data");


                find = details.getJSONObject(0);
                char tmp = 0x00B0;

                cityTextView.setText(find.getString("city_name"));
                stateName = find.getString("state_code");
                countryName = find.getString("country_code");
                stateTextView.setText(stateName + ", " + countryName);

                temp_double = Double.parseDouble(find.getString("temp"));
                temperatureTextView.setText(String.format("%.0f", temp_double)+"F");
                //temperatureTextView.setText(find.getString("temp")+"F");

                JSONObject weather = find.getJSONObject("weather");
                String desc = weather.getString("description");
                descriptionTextView.setText(desc);

                precip_double = Double.parseDouble(find.getString("precip"));
                precipTextView.setText(String.format("%.1f", precip_double)+"mm");
                //precipTextView.setText(find.getString("precip")+"mm");

                uv_double = Double.parseDouble(find.getString("uv"));
                uvTextView.setText(String.format("%.2f", uv_double));

                feels_double = Double.parseDouble(find.getString("app_temp"));
                feelsTextView.setText(String.format("%.1f", feels_double)+"F");
                //feelsTextView.setText(find.getString("app_temp")+"F");

                rh_double = Double.parseDouble(find.getString("rh"));
                humidityTextView.setText(String.format("%.1f", rh_double)+"%");
                //humidityTextView.setText(find.getString("rh")+"%");



            } catch (JSONException e) {
                Toast.makeText(this, "Something went wrong, Please try again and check the city name", Toast.LENGTH_SHORT).show();

            }
        }, error -> {

        });

        Volley.newRequestQueue(this).add(request);

    }

    public void backtoCity(View view) {
        Intent intent = new Intent(this,City_Weather.class);
        startActivity(intent);
        finish();
    }
}