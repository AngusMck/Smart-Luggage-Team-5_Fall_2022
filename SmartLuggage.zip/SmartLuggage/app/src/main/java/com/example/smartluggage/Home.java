package com.example.smartluggage;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.vmadalin.easypermissions.EasyPermissions;

public class Home extends AppCompatActivity implements LocationListener {

    // make lat and long public to be used in maps activity
    public static double latitude;
    public static double longitude;
    // location manager provides access to the system location services (access to built in services)
    LocationManager locationManager;
    // use PERMISSIONS to determine if granted/need to request
    final static String[] PERMISSIONS = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
    final static int PERMISSIONS_ALL = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_home);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        // if android version is newer than 23 request location permission
        // older versions don't require this
        if(Build.VERSION.SDK_INT >= 23){
            // call the request permission class below
            requestPermissions(PERMISSIONS, PERMISSIONS_ALL);
        }

        // request location now
        // make a handler to call request location every x amount of seconds
        // handler acts as a for loop in the on create in order to continuously call on the request
        // location function
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // call on the request location function
                requestLocation();
                // handler adds a 1s delay here
                handler.postDelayed(this, 1000);
            }
        }, 1000); // runs every 1 second (2 secs total for handler loop)

    }

    // need to update the long and lat whenever location is changed
    @Override
    public void onLocationChanged(@NonNull Location location) {
        longitude = location.getLongitude();
        latitude = location.getLatitude();
        // Removes all location updates for the specified listener
        locationManager.removeUpdates(this);
    }

    // callback for calling for permissions (read the user input)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            // request location now if permission granted
            // make a handler to call request location every x amount of seconds
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    requestLocation();
                    handler.postDelayed(this, 1000);
                }
            }, 1000); // runs every 1 second
        }
    }

    // obtain the location of the user
    public void requestLocation() {
        // need location manager
        if(locationManager == null) {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        }
        // check if GPS is enabled
        // NETWORK_PROVIDER (works in zach) > GPS_PROVIDER (very slow in zach)
        // NETWORK_PROVIDER works much better indoors as it determines location based
        // on availability of cell tower and WiFi access points.
        if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                // 1000ms = check location every 1 sec
                // 1m = need to move greater than 1 meter
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, this);
                // on location changed manages the change in location and updates long and lat
            }
        }
    }

    public void movetoNavigation(View view) {
        Intent intent = new Intent(this,Navigation.class);
        startActivity(intent);
        finish();
    }
}