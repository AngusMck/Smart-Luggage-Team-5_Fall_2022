package com.example.smartluggage;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.Timer;

public class Journey extends AppCompatActivity {

    public static double first_lat;
    public static double first_long;
    public static double last_lat;
    public static double last_long;
    private static int interval = 1000; // update every 1 sec for now

    public static ArrayList<LatLng> coordList = new ArrayList<LatLng>();

    private Button StartButton;
    private Button StopButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_city_weather);
        setContentView(R.layout.activity_journey);

        StartButton = findViewById(R.id.StartButton);
        StopButton = findViewById(R.id.StopButton);

        StartButton.setEnabled(true);
        StopButton.setEnabled(true);
    }

    public void onClickStart(View view) {
        coordList.clear();
        StartButton.setEnabled(false);
        StopButton.setEnabled(true);
        first_lat = Home.latitude;
        first_long = Home.longitude; // keep these to set camera zoom and location
        coordList.add(new LatLng(first_lat, first_long));

        for (int i = 0; i < 300000;) { // 300000 = 5 minutes
            // start with 1 second delay
            for (int j = 0; j < interval; ) { // "interval" second counter
                j = j + 1;
            }
            // update coords to list
            coordList.add(new LatLng(Home.latitude, Home.longitude));
            // break if stop button is pressed
            if (StopButton.isPressed() == true) {
                break;
            }
            // increment counter
            i = i + 1;
        }
    }

    public void onClickStop(View view) {
        last_lat = Home.latitude;
        last_long = Home.longitude;
        coordList.add(new LatLng(last_lat, last_long));
        Intent intent = new Intent(this, JourneyMap.class);
        startActivity(intent);
        finish();
    }

    public void backtoNavigation(View view) {
        Intent intent = new Intent(this, Navigation.class);
        startActivity(intent);
        finish();
    }
}

